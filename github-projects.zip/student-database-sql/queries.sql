-- 1. All students with their department
SELECT s.name, d.dept_name
FROM students s
JOIN departments d ON d.dept_id = s.dept_id
ORDER BY s.name;

-- 2. Number of students per department (including empty departments)
SELECT d.dept_name, COUNT(s.student_id) AS total_students
FROM departments d
LEFT JOIN students s ON s.dept_id = d.dept_id
GROUP BY d.dept_id, d.dept_name
ORDER BY total_students DESC;

-- 3. Average grade per course
SELECT c.title, ROUND(AVG(e.grade), 2) AS avg_grade
FROM courses c
JOIN enrollments e ON e.course_id = c.course_id
GROUP BY c.course_id, c.title
ORDER BY avg_grade DESC;

-- 4. Top scorer in each course
SELECT c.title, s.name, e.grade
FROM enrollments e
JOIN students s ON s.student_id = e.student_id
JOIN courses c  ON c.course_id  = e.course_id
WHERE e.grade = (SELECT MAX(grade) FROM enrollments WHERE course_id = e.course_id)
ORDER BY c.title;

-- 5. Students with an average grade above 85
SELECT s.name, ROUND(AVG(e.grade), 2) AS avg_grade
FROM students s
JOIN enrollments e ON e.student_id = s.student_id
GROUP BY s.student_id, s.name
HAVING AVG(e.grade) > 85;

-- 6. Students not enrolled in any course
SELECT s.name
FROM students s
LEFT JOIN enrollments e ON e.student_id = s.student_id
WHERE e.student_id IS NULL;

-- 7. Total credits per student
SELECT s.name, SUM(c.credits) AS total_credits
FROM students s
JOIN enrollments e ON e.student_id = s.student_id
JOIN courses c ON c.course_id = e.course_id
GROUP BY s.student_id, s.name
ORDER BY total_credits DESC;
