# Student Management Database (SQL)

A relational database design for a college: departments, students, courses and enrollments, with constraints, indexes and analytical queries.

## Files
- `schema.sql` - tables, primary/foreign keys, CHECK constraints, indexes
- `data.sql` - sample data
- `queries.sql` - joins, aggregates, GROUP BY / HAVING, subqueries

## Run (SQLite)
```bash
sqlite3 college.db < schema.sql
sqlite3 college.db < data.sql
sqlite3 -header -column college.db < queries.sql
```

## Concepts used
Normalisation, foreign keys, INNER/LEFT joins, aggregation, correlated subqueries.

## Author
M Karthik
