INSERT INTO departments (dept_id, dept_name) VALUES
    (1, 'Computer Science'),
    (2, 'Electronics'),
    (3, 'Mechanical');

INSERT INTO students (student_id, name, email, dept_id, join_year) VALUES
    (1, 'Asha Rao',     'asha@example.com',   1, 2022),
    (2, 'Rahul Gowda',  'rahul@example.com',  1, 2022),
    (3, 'Meera Nair',   'meera@example.com',  2, 2023),
    (4, 'Vikram Shetty','vikram@example.com', 3, 2021),
    (5, 'Divya Kumar',  'divya@example.com',  1, 2023);

INSERT INTO courses (course_id, title, credits, dept_id) VALUES
    (101, 'Data Structures',      4, 1),
    (102, 'Database Systems',     4, 1),
    (103, 'Digital Electronics',  3, 2),
    (104, 'Thermodynamics',       3, 3);

INSERT INTO enrollments (student_id, course_id, grade) VALUES
    (1, 101, 88), (1, 102, 92),
    (2, 101, 75), (2, 102, 81),
    (3, 103, 90),
    (4, 104, 68),
    (5, 101, 95);
