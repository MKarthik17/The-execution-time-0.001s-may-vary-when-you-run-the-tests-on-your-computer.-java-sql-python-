"""Command-line expense tracker that stores data in a local JSON file."""
import argparse
import json
import sys
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path

DEFAULT_FILE = Path("expenses.json")


def load_expenses(path=DEFAULT_FILE):
    path = Path(path)
    if not path.exists():
        return []
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"Warning: {path} is corrupted; starting with an empty list.", file=sys.stderr)
        return []


def save_expenses(expenses, path=DEFAULT_FILE):
    with Path(path).open("w", encoding="utf-8") as f:
        json.dump(expenses, f, indent=2)


def add_expense(expenses, amount, category, note="", when=None):
    if amount <= 0:
        raise ValueError("Amount must be greater than zero")
    when = when or date.today().isoformat()
    datetime.strptime(when, "%Y-%m-%d")  # validates the date format
    expense = {
        "id": max((e["id"] for e in expenses), default=0) + 1,
        "amount": round(float(amount), 2),
        "category": category.strip().lower(),
        "note": note,
        "date": when,
    }
    expenses.append(expense)
    return expense


def summarize(expenses):
    totals = defaultdict(float)
    for e in expenses:
        totals[e["category"]] += e["amount"]
    return dict(sorted(totals.items(), key=lambda kv: kv[1], reverse=True))


def build_parser():
    parser = argparse.ArgumentParser(description="Simple expense tracker")
    parser.add_argument("--file", default=str(DEFAULT_FILE), help="JSON data file")
    sub = parser.add_subparsers(dest="command", required=True)

    add = sub.add_parser("add", help="add an expense")
    add.add_argument("amount", type=float)
    add.add_argument("category")
    add.add_argument("--note", default="")
    add.add_argument("--date", help="YYYY-MM-DD (default: today)")

    sub.add_parser("list", help="list all expenses")
    sub.add_parser("summary", help="total spent per category")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    expenses = load_expenses(args.file)

    if args.command == "add":
        try:
            e = add_expense(expenses, args.amount, args.category, args.note, args.date)
        except ValueError as err:
            print(f"Error: {err}", file=sys.stderr)
            return 1
        save_expenses(expenses, args.file)
        print(f"Added #{e['id']}: {e['amount']:.2f} on {e['category']} ({e['date']})")
    elif args.command == "list":
        if not expenses:
            print("No expenses recorded.")
        for e in expenses:
            print(f"#{e['id']:<3} {e['date']}  {e['category']:<12} {e['amount']:>9.2f}  {e['note']}")
    elif args.command == "summary":
        totals = summarize(expenses)
        for cat, total in totals.items():
            print(f"{cat:<12} {total:>9.2f}")
        print(f"{'TOTAL':<12} {sum(totals.values()):>9.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
