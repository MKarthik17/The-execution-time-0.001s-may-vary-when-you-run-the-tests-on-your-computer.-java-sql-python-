import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from expense_tracker import add_expense, summarize  # noqa: E402


class ExpenseTrackerTests(unittest.TestCase):
    def test_add_assigns_incrementing_ids(self):
        expenses = []
        a = add_expense(expenses, 10, "Food")
        b = add_expense(expenses, 5, "Travel")
        self.assertEqual((a["id"], b["id"]), (1, 2))

    def test_category_is_normalised(self):
        expenses = []
        self.assertEqual(add_expense(expenses, 10, " Food ")["category"], "food")

    def test_rejects_non_positive_amount(self):
        with self.assertRaises(ValueError):
            add_expense([], 0, "food")

    def test_rejects_bad_date(self):
        with self.assertRaises(ValueError):
            add_expense([], 5, "food", when="24-10-2026")

    def test_summary_totals_by_category(self):
        expenses = []
        add_expense(expenses, 10, "food")
        add_expense(expenses, 15.5, "food")
        add_expense(expenses, 7, "travel")
        self.assertEqual(summarize(expenses), {"food": 25.5, "travel": 7.0})


if __name__ == "__main__":
    unittest.main()
