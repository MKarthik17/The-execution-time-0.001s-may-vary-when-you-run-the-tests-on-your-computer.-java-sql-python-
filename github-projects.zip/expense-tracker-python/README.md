# Expense Tracker (Python)

A command-line expense tracker using only the Python standard library. Data is stored in a local JSON file.

## Requirements
- Python 3.8+

## Usage
```bash
python expense_tracker.py add 250 food --note "Lunch"
python expense_tracker.py add 1200 travel --date 2026-10-20
python expense_tracker.py list
python expense_tracker.py summary
```

## Run tests
```bash
python -m unittest discover -s tests
```

## Concepts used
`argparse` sub-commands, JSON file handling, input validation, `defaultdict`, unit testing with `unittest`.

## Author
M Karthik
