#!/usr/bin/env bash
# Run this on YOUR computer, after logging in to GitHub (gh auth login) or having git credentials set up.
set -e
USER_NAME="MKarthik17"
PROJECTS=(library-management-java expense-tracker-python student-database-sql)

for p in "${PROJECTS[@]}"; do
  echo "==> $p"
  cd "$p"
  [ -d .git ] || git init -b main
  git config user.name "M Karthik"
  git add .
  git commit -m "Initial commit: $p" || echo "Nothing new to commit"
  if command -v gh >/dev/null 2>&1; then
    gh repo create "$USER_NAME/$p" --public --source=. --remote=origin --push \
      || git push -u origin main
  else
    git remote get-url origin >/dev/null 2>&1 || git remote add origin "https://github.com/$USER_NAME/$p.git"
    echo "Create an empty repo named '$p' on github.com first, then:"
    git push -u origin main
  fi
  cd ..
done
echo "All done. Check https://github.com/$USER_NAME?tab=repositories"
