import java.util.ArrayList;
import java.util.List;

public class Library {
    private final List<Book> books = new ArrayList<>();
    private int nextId = 1;

    public Book addBook(String title, String author) {
        if (title == null || title.isBlank() || author == null || author.isBlank()) {
            throw new IllegalArgumentException("Title and author must not be empty");
        }
        Book book = new Book(nextId++, title.trim(), author.trim());
        books.add(book);
        return book;
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }

    public List<Book> search(String keyword) {
        String key = keyword.toLowerCase();
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(key)
                    || b.getAuthor().toLowerCase().contains(key)) {
                result.add(b);
            }
        }
        return result;
    }

    private Book findById(int id) {
        for (Book b : books) {
            if (b.getId() == id) return b;
        }
        throw new IllegalArgumentException("No book found with id " + id);
    }

    public void issueBook(int id) {
        Book b = findById(id);
        if (b.isIssued()) throw new IllegalStateException("Book is already issued");
        b.setIssued(true);
    }

    public void returnBook(int id) {
        Book b = findById(id);
        if (!b.isIssued()) throw new IllegalStateException("Book was not issued");
        b.setIssued(false);
    }
}
