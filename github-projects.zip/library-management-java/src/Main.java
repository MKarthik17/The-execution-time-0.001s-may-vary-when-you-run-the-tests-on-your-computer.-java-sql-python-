import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook("Clean Code", "Robert C. Martin");
        library.addBook("Effective Java", "Joshua Bloch");
        library.addBook("Introduction to Algorithms", "Thomas H. Cormen");

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Library Management ---");
            System.out.println("1. List books");
            System.out.println("2. Add book");
            System.out.println("3. Search books");
            System.out.println("4. Issue book");
            System.out.println("5. Return book");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            if (!sc.hasNextLine()) break;
            String choice = sc.nextLine().trim();

            try {
                switch (choice) {
                    case "1" -> library.getAllBooks().forEach(System.out::println);
                    case "2" -> {
                        System.out.print("Title: ");
                        String title = sc.nextLine();
                        System.out.print("Author: ");
                        String author = sc.nextLine();
                        System.out.println("Added: " + library.addBook(title, author));
                    }
                    case "3" -> {
                        System.out.print("Keyword: ");
                        List<Book> found = library.search(sc.nextLine());
                        if (found.isEmpty()) System.out.println("No matching books.");
                        else found.forEach(System.out::println);
                    }
                    case "4" -> {
                        System.out.print("Book id: ");
                        library.issueBook(Integer.parseInt(sc.nextLine().trim()));
                        System.out.println("Book issued.");
                    }
                    case "5" -> {
                        System.out.print("Book id: ");
                        library.returnBook(Integer.parseInt(sc.nextLine().trim()));
                        System.out.println("Book returned.");
                    }
                    case "6" -> {
                        System.out.println("Goodbye!");
                        return;
                    }
                    default -> System.out.println("Invalid option, try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter a valid number.");
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
