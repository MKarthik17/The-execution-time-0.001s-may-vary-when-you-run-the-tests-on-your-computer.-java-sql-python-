# Library Management System (Java)

A console-based library management app built with core Java (OOP, collections, exception handling).

## Features
- Add, list and search books (by title or author)
- Issue and return books with validation
- Clear error messages for invalid input

## Requirements
- JDK 17 or newer

## Run
```bash
mkdir out
javac -d out src/*.java
java -cp out Main
```

## Concepts used
Classes and encapsulation, `ArrayList`, enhanced `switch`, custom input validation, exceptions.

## Author
M Karthik
